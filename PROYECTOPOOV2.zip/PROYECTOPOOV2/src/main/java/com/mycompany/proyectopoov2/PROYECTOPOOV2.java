package com.mycompany.proyectopoov2;

public class PROYECTOPOOV2 {
    public static void main(String[] args) {

        BaseDatos db = new BaseDatos();
        db.datosIniciales();  // carga admin y recep + habitaciones + servicios

        new LoginSistema(db).setVisible(true);
    }
}

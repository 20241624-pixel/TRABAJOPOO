package com.mycompany.proyectopoov2;

import javax.swing.*;
import java.awt.*;

public class LoginSistema extends JFrame {

    private final BaseDatos db;

    private final Color CREMA = new Color(250, 248, 240);
    private final Color DORADO = new Color(214, 185, 120);
    private final Color DORADO_OSCURO = new Color(190, 160, 100);

    public LoginSistema(BaseDatos db) {
        this.db = db;
        initUI();
    }

    private JButton boton(String txt) {
        JButton b = new JButton(txt);
        b.setBackground(DORADO);
        b.setFont(new Font("Segoe UI", Font.BOLD, 16));
        b.setFocusPainted(false);

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(DORADO_OSCURO); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(DORADO); }
        });

        return b;
    }

    private void initUI() {
        setTitle("Inicio de Sesión");
        setSize(420, 330);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(CREMA);
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(10,10,10,10);

        JLabel titulo = new JLabel("Sistema Hotelero");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 24));

        JLabel lUser = new JLabel("Usuario:");
        JLabel lPass = new JLabel("Contraseña:");

        JTextField txtUser = new JTextField(15);
        JPasswordField txtPass = new JPasswordField(15);

        JButton btnLogin = boton("Ingresar");

        gc.gridx=0; gc.gridy=0; gc.gridwidth=2;
        panel.add(titulo, gc);

        gc.gridwidth=1;
        gc.gridy=1; gc.gridx=0; panel.add(lUser, gc);
        gc.gridx=1; panel.add(txtUser, gc);

        gc.gridy=2; gc.gridx=0; panel.add(lPass, gc);
        gc.gridx=1; panel.add(txtPass, gc);

        gc.gridy=3; gc.gridx=0; gc.gridwidth=2;
        panel.add(btnLogin, gc);

        add(panel);

        //  LOGIN 
        btnLogin.addActionListener(e -> {
            String u = txtUser.getText().trim();
            String c = new String(txtPass.getPassword()).trim();

            Empleado emp = db.login(u, c);

            if(emp == null) {
                JOptionPane.showMessageDialog(this,
                        "Usuario o contraseña incorrectos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            //  RUTEO 
            if(emp instanceof Administrador) {
                new InterfazAdmin(db).setVisible(true);
                dispose();
            }
            else if(emp instanceof Recepcionista) {
                new InterfazRecepcionista(db).setVisible(true);
                dispose();
            }
        });
    }
}

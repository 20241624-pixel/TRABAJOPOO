/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package com.mycompany.proyectopoov2;

import java.time.LocalDate;

public class Reserva {

    private static int IDACTUAL = 1;

    private int id;
    private Huesped huesped;
    private String tipoHabitacion;
    private LocalDate inicio;
    private LocalDate fin;
    private boolean cancelada = false;
    private Integer habitacionAsignada = null;

    public Reserva(Huesped huesped, String tipo, LocalDate inicio, LocalDate fin) {
        this.id = IDACTUAL++;
        this.huesped = huesped;
        this.tipoHabitacion = tipo;
        this.inicio = inicio;
        this.fin = fin;
    }

    // Getters / Setters
    public int getId() { return id; }
    public Huesped getHuesped() { return huesped; }
    public String getTipoHabitacion() { return tipoHabitacion; }

    public LocalDate getInicio() { return inicio; }
    public LocalDate getFin() { return fin; }

    public void setInicio(LocalDate inicio) { this.inicio = inicio; }
    public void setFin(LocalDate fin) { this.fin = fin; }

    public boolean isCancelada() { return cancelada; }
    public void setCancelada(boolean cancelada) { this.cancelada = cancelada; }

    public Integer getHabitacionAsignada() { return habitacionAsignada; }
    public void setHabitacionAsignada(Integer habitacionAsignada) { this.habitacionAsignada = habitacionAsignada; }

    @Override
    public String toString() {
        return "Reserva #" + id + " - " + (huesped != null ? huesped.toString() : "Huésped N/D") +
               " (" + inicio + " → " + fin + ") " + (cancelada ? "[CANCELADA]" : "");
    }
}

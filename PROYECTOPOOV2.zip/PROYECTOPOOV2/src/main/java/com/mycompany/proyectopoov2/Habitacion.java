/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectopoov2;

public class Habitacion {

    public enum Estado { LIMPIA, SUCIA, OCUPADA }

    private int numero;
    private String tipo;
    private int capacidad;
    private double precioNoche;
    private Estado estado;

    public Habitacion(int numero, String tipo, int capacidad, double precioNoche) {
        this.numero = numero;
        this.tipo = tipo;
        this.capacidad = capacidad;
        this.precioNoche = precioNoche;
        this.estado = Estado.LIMPIA;
    }

    public int getNumero() { return numero; }
    public String getTipo() { return tipo; }
    public int getCapacidad() { return capacidad; }
    public double getPrecioNoche() { return precioNoche; }
    public Estado getEstado() { return estado; }

    public void setEstado(Estado e) { this.estado = e; }

    @Override
    public String toString() {
        return "Hab " + numero + " (" + tipo + ") - " + estado;
    }
}

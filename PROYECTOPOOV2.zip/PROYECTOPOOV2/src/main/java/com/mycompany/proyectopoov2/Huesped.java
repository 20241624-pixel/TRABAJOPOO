/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectopoov2;

public class Huesped extends Persona {

    public Huesped(String dni, String nombres, String apellidos, String contacto) {
        super(dni, nombres, apellidos, contacto);
    }
    
   
}

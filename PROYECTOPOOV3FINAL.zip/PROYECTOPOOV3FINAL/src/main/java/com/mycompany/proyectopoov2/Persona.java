package com.mycompany.proyectopoov2;

public class Persona {

    protected String dni;
    protected String nombres;
    protected String apellidos;
    protected String contacto;

    public Persona(String dni, String nombres, String apellidos, String contacto) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.contacto = contacto;
    }

    //  GETTERS 
    public String getDni() { return dni; }
    public String getNombres() { return nombres; }
    public String getApellidos() { return apellidos; }
    public String getContacto() { return contacto; }

    //  SETTERS 
    public void setNombres(String nombres) { this.nombres = nombres; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    public void setContacto(String contacto) { this.contacto = contacto; }

    @Override
    public String toString() {
        return dni + " - " + nombres + " " + apellidos + " (" + contacto + ")";
    }
}

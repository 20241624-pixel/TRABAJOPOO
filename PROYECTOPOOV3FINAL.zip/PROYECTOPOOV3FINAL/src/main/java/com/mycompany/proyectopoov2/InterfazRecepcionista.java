package com.mycompany.proyectopoov2;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.Date;

public class InterfazRecepcionista extends JFrame {

    private final BaseDatos db;

    private final Color CREMA = new Color(250, 248, 240);
    private final Color DORADO = new Color(214, 185, 120);
    private final Color DORADO_OSCURO = new Color(190, 160, 100);

    public InterfazRecepcionista(BaseDatos db) {
        this.db = db;
        initUI();
    }

    private JButton boton(String txt) {
        JButton b = new JButton(txt);
        b.setBackground(DORADO);
        b.setFont(new Font("Segoe UI", Font.BOLD, 15));
        b.setFocusPainted(false);

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(DORADO_OSCURO); }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(DORADO); }
        });

        return b;
    }

    private void initUI() {
        setTitle("Recepcionista - Sistema Hotelero");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        JPanel menu = new JPanel(new GridLayout(9, 1, 10, 10));
        menu.setBackground(CREMA);
        menu.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JButton bRegistrar = boton("Registrar Huésped");
        JButton bEditar = boton("Editar Huésped");
        JButton bEliminar = boton("Eliminar Huésped");
        JButton bReserva = boton("Crear Reserva");
        JButton bCheckIn = boton("Check-In");
        JButton bServicio = boton("Agregar Servicio");
        JButton bCheckOut = boton("Check-Out");
        JButton bListas = boton("Ver Listas");
        JButton bCerrar = boton("Cerrar Sesión");


        menu.add(bRegistrar);
        menu.add(bEditar);
        menu.add(bEliminar);
        menu.add(bReserva);
        menu.add(bCheckIn);
        menu.add(bServicio);
        menu.add(bCheckOut);
        menu.add(bListas);
        menu.add(bCerrar);


        add(menu, BorderLayout.WEST);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Consolas", Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(area);
        add(sp, BorderLayout.CENTER);

        //  ACCIONES 

        bRegistrar.addActionListener(e -> registrarHuesped());
        bEditar.addActionListener(e -> editarHuesped());
        bEliminar.addActionListener(e -> eliminarHuesped());
        bReserva.addActionListener(e -> crearReserva());
        bCheckIn.addActionListener(e -> hacerCheckIn());
        bServicio.addActionListener(e -> agregarServicio());
        bCheckOut.addActionListener(e -> hacerCheckOut());
        bListas.addActionListener(e -> mostrarListas(area));
        bCerrar.addActionListener(e -> {
            dispose();                           
            new LoginSistema(db).setVisible(true);  
        });

    }
    
   
    //               REGISTRAR HUESPED
    private void registrarHuesped() {
        JTextField dni = new JTextField();
        JTextField nom = new JTextField();
        JTextField ape = new JTextField();
        JTextField tel = new JTextField();

        JPanel p = new JPanel(new GridLayout(4,2,6,6));
        p.add(new JLabel("DNI:")); p.add(dni);
        p.add(new JLabel("Nombres:")); p.add(nom);
        p.add(new JLabel("Apellidos:")); p.add(ape);
        p.add(new JLabel("Teléfono:")); p.add(tel);

        int r = JOptionPane.showConfirmDialog(this, p, "Registrar Huésped", JOptionPane.OK_CANCEL_OPTION);
        if(r != JOptionPane.OK_OPTION) return;

        Huesped h = new Huesped(dni.getText(), nom.getText(), ape.getText(), tel.getText());
        db.agregarHuesped(h);

        JOptionPane.showMessageDialog(this, "Huésped registrado correctamente.");
    }

    //               EDITAR HUESPED
    private void editarHuesped() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        Huesped h = db.buscarHuespedPorDNI(dni.trim());
        if (h == null) {
            JOptionPane.showMessageDialog(this, "No existe.");
            return;
        }

        JTextField nom = new JTextField(h.getNombres());
        JTextField ape = new JTextField(h.getApellidos());
        JTextField tel = new JTextField(h.getContacto());

        JPanel p = new JPanel(new GridLayout(3,2,6,6));
        p.add(new JLabel("Nombres:")); p.add(nom);
        p.add(new JLabel("Apellidos:")); p.add(ape);
        p.add(new JLabel("Contacto:")); p.add(tel);

        int r = JOptionPane.showConfirmDialog(this, p, "Editar Huésped", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        h.setNombres(nom.getText());
        h.setApellidos(ape.getText());
        h.setContacto(tel.getText());

        JOptionPane.showMessageDialog(this, "Datos actualizados.");
    }

    //               ELIMINAR HUESPED
    private void eliminarHuesped() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        for (int i = 0; i < db.cantHuespedes; i++) {
            if (db.huespedes[i] != null && db.huespedes[i].getDni().equals(dni.trim())) {
                db.huespedes[i] = null;
                JOptionPane.showMessageDialog(this, "Eliminado.");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "No encontrado.");
    }

    //               CREAR RESERVA (CON JSPINNER)
    private void crearReserva() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        Huesped h = db.buscarHuespedPorDNI(dni.trim());
        if (h == null) {
            JOptionPane.showMessageDialog(this, "No existe huésped.");
            return;
        }

        String tipo = JOptionPane.showInputDialog(this, "Tipo (Simple/Doble/Suite):");
        if (tipo == null) return;

        Habitacion hab = db.buscarHabitacionDisponiblePorTipo(tipo.trim());
        if (hab == null) {
            JOptionPane.showMessageDialog(this, "No hay habitaciones disponibles.");
            return;
        }

        // Calendarios
        JSpinner ini = new JSpinner(new SpinnerDateModel());
        ini.setEditor(new JSpinner.DateEditor(ini, "yyyy-MM-dd"));

        JSpinner fin = new JSpinner(new SpinnerDateModel());
        fin.setEditor(new JSpinner.DateEditor(fin, "yyyy-MM-dd"));

        JPanel p = new JPanel(new GridLayout(2,2,5,5));
        p.add(new JLabel("Fecha inicio:")); p.add(ini);
        p.add(new JLabel("Fecha fin:")); p.add(fin);

        int r = JOptionPane.showConfirmDialog(this, p, "Fechas", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        LocalDate f1 = ((Date) ini.getValue()).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        LocalDate f2 = ((Date) fin.getValue()).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();

        Reserva res = new Reserva(h, tipo.trim(), f1, f2);
        db.agregarReserva(res);

        JOptionPane.showMessageDialog(this, "Reserva creada. ID: " + res.getId());
    }

    //               CHECK-IN
    private void hacerCheckIn() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        Reserva r = db.buscarReservaPorHuesped(dni.trim());
        if (r == null) {
            JOptionPane.showMessageDialog(this, "No existe reserva.");
            return;
        }

        Habitacion hab = db.buscarHabitacionDisponiblePorTipo(r.getTipoHabitacion());
        if (hab == null) {
            JOptionPane.showMessageDialog(this, "No hay habitación disponible.");
            return;
        }

        hab.setEstado(Habitacion.Estado.OCUPADA);
        Estadia e = new Estadia(r, hab, LocalDate.now());
        db.agregarEstadia(e);

        JOptionPane.showMessageDialog(this, "Check-In completado.");
    }

    //               AGREGAR SERVICIOS
    private void agregarServicio() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        Estadia e = db.buscarEstadiaPorHuesped(dni.trim());
        if (e == null) {
            JOptionPane.showMessageDialog(this, "El huésped no está hospedado.");
            return;
        }

        String lista = "";
        for (int i = 0; i < db.cantServicios; i++) {
            lista += (i + 1) + ". " + db.servicios[i].getNombre() + " (S/ " + db.servicios[i].getPrecio() + ")\n";
        }

        String opc = JOptionPane.showInputDialog(this, "Servicios:\n" + lista);
        if (opc == null) return;

        int idx = Integer.parseInt(opc) - 1;

        if (idx < 0 || idx >= db.cantServicios) {
            JOptionPane.showMessageDialog(this, "Opción inválida.");
            return;
        }

        e.agregarServicio(db.servicios[idx]);
        JOptionPane.showMessageDialog(this, "Servicio añadido.");
    }
    //               CHECK-OUT (TOTAL)
    private void hacerCheckOut() {
        String dni = JOptionPane.showInputDialog(this, "DNI:");
        if (dni == null) return;

        Estadia e = db.buscarEstadiaPorHuesped(dni.trim());
        if (e == null) {
            JOptionPane.showMessageDialog(this, "No tiene estadía activa.");
            return;
        }

        e.setCheckOut(LocalDate.now());

        double total = e.calcularTotal();

        // Liberar habitación
        e.getHabitacion().setEstado(Habitacion.Estado.LIMPIA);

        JOptionPane.showMessageDialog(this,
                "CHECK-OUT COMPLETADO\n" +
                "Total a pagar: S/ " + total);
    }
    
    //               MOSTRAR LISTAS
    private void mostrarListas(JTextArea area) {
    area.setText("");

    area.append("===== HUESPEDES =====\n");
    for (int i = 0; i < db.cantHuespedes; i++) {
        if (db.huespedes[i] != null)
            area.append(db.huespedes[i] + "\n");
    }

    area.append("\n===== RESERVAS =====\n");
    area.append(db.listarReservas() + "\n");

    // ==========================
    //  LISTA DE HABITACIONES
    // ==========================
    area.append("\n===== HABITACIONES (con precios) =====\n");

    for (int i = 0; i < db.cantHabitaciones; i++) {
        Habitacion h = db.habitaciones[i];
        if (h != null) {
            area.append(
                "Hab #" + h.getNumero() +
                "  | Tipo: " + h.getTipo() +
                "  | Estado: " + h.getEstado() +
                "  | Precio/noche: S/ " + h.getPrecioNoche() +
                "\n"
            );
        }
    }

    //  LISTA DE SERVICIOS
    area.append("\n===== SERVICIOS =====\n");
    area.append(db.listarServicios());
}

}

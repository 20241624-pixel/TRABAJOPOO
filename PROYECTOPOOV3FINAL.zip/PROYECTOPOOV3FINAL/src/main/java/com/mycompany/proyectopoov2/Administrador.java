/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectopoov2;

public class Administrador extends Empleado {

    public Administrador(String dni, String nombres, String apellidos, String contacto,
                         String usuario, String clave) {

        super(dni, nombres, apellidos, contacto, usuario, clave);
    }

    @Override
    public String getRol() {
        return "ADMINISTRADOR";
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectopoov2;

public abstract class Empleado extends Persona implements Autenticable {

    protected String usuario;
    protected String clave;

    public Empleado(String dni, String nombres, String apellidos, String contacto,
                    String usuario, String clave) {

        super(dni, nombres, apellidos, contacto);
        this.usuario = usuario;
        this.clave = clave;
    }

    @Override
    public boolean autenticar(String u, String c) {
        return this.usuario.equals(u) && this.clave.equals(c);
    }

    @Override
    public abstract String getRol();
}

package com.mycompany.proyectopoov2;

import java.time.LocalDate;



public class BaseDatos {

    
    
    public Empleado[] empleados = new Empleado[20];
    public int cantEmpleados = 0;

    public Huesped[] huespedes = new Huesped[100];
    public int cantHuespedes = 0;

    public Habitacion[] habitaciones = new Habitacion[100];
    public int cantHabitaciones = 0;

    public Servicio[] servicios = new Servicio[100];
    public int cantServicios = 0;

    public Reserva[] reservas = new Reserva[200];
    public int cantReservas = 0;

    public Estadia[] estadias = new Estadia[200];
    public int cantEstadias = 0;

    // -------- MÉTODOS CRUD --------

    public void agregarEmpleado(Empleado e) {
        if (cantEmpleados < empleados.length) empleados[cantEmpleados++] = e;
    }

    public void agregarHuesped(Huesped h) {
        if (cantHuespedes < huespedes.length) huespedes[cantHuespedes++] = h;
    }

    public void agregarHabitacion(Habitacion h) {
        if (cantHabitaciones < habitaciones.length) habitaciones[cantHabitaciones++] = h;
    }

    public void agregarServicio(Servicio s) {
        if (cantServicios < servicios.length) servicios[cantServicios++] = s;
    }

    public void agregarReserva(Reserva r) {
        if (cantReservas < reservas.length) reservas[cantReservas++] = r;
    }

    public void agregarEstadia(Estadia e) {
        if (cantEstadias < estadias.length) estadias[cantEstadias++] = e;
    }

    //     MÉTODOS DE BUSQUEDA

    public Huesped buscarHuespedPorDNI(String dni) {
        if (dni == null) return null;
        for (int i = 0; i < cantHuespedes; i++) {
            Huesped h = huespedes[i];
            if (h != null && dni.equals(h.getDni())) return h;
        }
        return null;
    }

    public Reserva buscarReservaPorId(int id) {
        for (int i = 0; i < cantReservas; i++) {
            Reserva r = reservas[i];
            if (r != null && r.getId() == id) return r;
        }
        return null;
    }

    public Estadia buscarEstadiaPorReserva(int idReserva) {
        for (int i = 0; i < cantEstadias; i++) {
            Estadia est = estadias[i];
            if (est == null) continue;
            Reserva r = est.getReserva();
            if (r != null && r.getId() == idReserva) return est;
        }
        return null;
    }

    public Habitacion buscarHabitacionDisponiblePorTipo(String tipo) {
        if (tipo == null) return null;
        for (int i = 0; i < cantHabitaciones; i++) {
            Habitacion h = habitaciones[i];
            if (h != null && tipo.equalsIgnoreCase(h.getTipo()) ) {
                // aquí deberías además verificar ocupación/estadías; simplifico y devuelvo la primera
                return h;
            }
        }
        return null;
    }

    //    LISTADOS (ÚTILES)

    public String listarReservas() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cantReservas; i++) {
            if (reservas[i] != null) sb.append(reservas[i]).append("\n");
        }
        return sb.toString();
    }

    public String listarHabitaciones() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cantHabitaciones; i++) {
            if (habitaciones[i] != null) sb.append(habitaciones[i]).append("\n");
        }
        return sb.toString();
    }

    public String listarServicios() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cantServicios; i++) {
            if (servicios[i] != null) sb.append(servicios[i]).append("\n");
        }
        return sb.toString();
    }

    // FUNCIONALIDADES PEDIDAS

    public boolean cancelarReserva(int id) {
        for (int i = 0; i < cantReservas; i++) {
            Reserva r = reservas[i];
            if (r != null && r.getId() == id) {
                r.setCancelada(true);
                return true;
            }
        }
        return false;
    }

    public boolean modificarReserva(int id, LocalDate nuevaFechaInicio, LocalDate nuevaFechaFin) {
        Reserva r = buscarReservaPorId(id);
        if (r != null) {
            r.setInicio(nuevaFechaInicio);
            r.setFin(nuevaFechaFin);
            return true;
        }
        return false;
    }

    // ------- LOGIN --------
    public Empleado login(String u, String c) {
        for (int i = 0; i < cantEmpleados; i++) {
            Empleado emp = empleados[i];
            if (emp != null && emp.autenticar(u, c)) return emp;
        }
        return null;
    }

    // ------- DATOS --------
    public void datosIniciales() {

        agregarEmpleado(new Administrador("0001", "Admin", "General", "999999999", "admin", "1234"));
        agregarEmpleado(new Recepcionista("0002", "Recep", "Uno", "988888888", "recep", "1234"));

        agregarHabitacion(new Habitacion(101, "Simple", 1, 100));
        agregarHabitacion(new Habitacion(102, "Doble", 2, 150));
        agregarHabitacion(new Habitacion(201, "Suite", 3, 250));
        agregarHabitacion(new Habitacion(202, "Suite Plus", 4, 300));


        agregarServicio(new Servicio("Desayuno", 20));
        agregarServicio(new Servicio("Lavandería", 30));
        agregarServicio(new Servicio("Masaje", 50));

    }
    
    
    // BUSCAR RESERVA POR DNI DE HUÉSPED
    public Reserva buscarReservaPorHuesped(String dni) {
        for (int i = 0; i < cantReservas; i++) {
            Reserva r = reservas[i];
            if (r != null && r.getHuesped().getDni().equals(dni)) {
                return r;
            }
        }
        return null;
    }

    // BUSCAR ESTADÍA ACTUAL POR DNI DE HUÉSPED
    public Estadia buscarEstadiaPorHuesped(String dni) {
        for (int i = 0; i < cantEstadias; i++) {
            Estadia e = estadias[i];
            if (e != null &&
                e.getReserva().getHuesped().getDni().equals(dni) &&
                e.getCheckOut() == null) {   
                return e;
            }
        }
        return null;
    }

    
}


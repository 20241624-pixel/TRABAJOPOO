/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package com.mycompany.proyectopoov2;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Estadia {
    private java.util.List<Servicio> consumos = new java.util.ArrayList<>();
    private Reserva reserva;
    private Habitacion habitacion;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private List<Servicio> servicios = new ArrayList<>();

    public Estadia(Reserva reserva, Habitacion habitacion, LocalDate checkIn) {
        this.reserva = reserva;
        this.habitacion = habitacion;
        this.checkIn = checkIn;
    }

    public Reserva getReserva() { return reserva; }
    public Habitacion getHabitacion() { return habitacion; }
    public LocalDate getCheckIn() { return checkIn; }
    public LocalDate getCheckOut() { return checkOut; }
    public List<Servicio> getServicios() { return servicios; }

    public void agregarServicio(Servicio s) { if (s != null) servicios.add(s); }
    public void setCheckOut(LocalDate d) { this.checkOut = d; }

    public double calcularTotal() {
        LocalDate end = checkOut != null ? checkOut : LocalDate.now();
        long noches = ChronoUnit.DAYS.between(checkIn, end);
        if (noches <= 0) noches = 1;
        double totalHab = noches * (habitacion != null ? habitacion.getPrecioNoche() : 0.0);
        double totalServ = servicios.stream().mapToDouble(Servicio::getPrecio).sum();
        return totalHab + totalServ;
    }

    @Override
    public String toString() {
        return "Estadia reserva#" + (reserva!=null ? reserva.getId() : "N/D") +
               " hab:" + (habitacion!=null ? habitacion.getNumero() : "N/D") +
               " in:" + checkIn + " out:" + checkOut;
    }
    
    
    
}

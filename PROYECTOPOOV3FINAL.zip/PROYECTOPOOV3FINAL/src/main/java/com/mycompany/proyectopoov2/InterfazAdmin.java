package com.mycompany.proyectopoov2;

import javax.swing.*;
import java.awt.*;

public class InterfazAdmin extends JFrame {

    private final BaseDatos db;

    private final Color CREMA = new Color(250, 248, 240);
    private final Color DORADO = new Color(214, 185, 120);
    private final Color DORADO_OSCURO = new Color(190, 160, 100);

    public InterfazAdmin (BaseDatos db) {
        this.db = db;
        initUI();
    }

    private JButton boton(String txt) {
        JButton b = new JButton(txt);
        b.setBackground(DORADO);
        b.setFont(new Font("Segoe UI", Font.BOLD, 15));
        b.setFocusPainted(false);

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(DORADO_OSCURO); }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(DORADO); }
        });

        return b;
    }

    private void initUI() {
        setTitle("Administrador - Sistema Hotelero");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        // PANEL IZQUIERDO — CATEGORÍAS
        JPanel menu = new JPanel(new GridLayout(10, 1, 10, 10));
        menu.setBackground(CREMA);
        menu.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JLabel titulo = new JLabel("Panel Administrador", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        menu.add(titulo);

        JButton bEmpleado = boton("Registrar Empleado");
        JButton bHabitacion = boton("Registrar Habitación");
        JButton bServicio = boton("Registrar Servicio");
        JButton bListas = boton("Ver Listas");
        JButton bCerrar = boton("Cerrar Sesión");

        menu.add(bEmpleado);
        menu.add(bHabitacion);
        menu.add(bServicio);
        menu.add(bListas);
        menu.add(bCerrar);

        add(menu, BorderLayout.WEST);

        // ÁREA CENTRAL
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Consolas", Font.PLAIN, 14));
        JScrollPane sp = new JScrollPane(area);
        add(sp, BorderLayout.CENTER);

        // ACCIONES
        bEmpleado.addActionListener(e -> registrarEmpleado());
        bHabitacion.addActionListener(e -> registrarHabitacion());
        bServicio.addActionListener(e -> registrarServicio());
        bListas.addActionListener(e -> mostrarListas(area));
        bCerrar.addActionListener(e -> {
            dispose();                               
            new LoginSistema(db).setVisible(true);    
        });
            }

    // ======================================================
    // REGISTRAR EMPLEADO NUEVO (CON ACCESO AL SISTEMA)
    // ======================================================
    private void registrarEmpleado() {

        String[] roles = {"Administrador", "Recepcionista"};
        JComboBox<String> rol = new JComboBox<>(roles);

        JTextField dni = new JTextField();
        JTextField nom = new JTextField();
        JTextField ape = new JTextField();
        JTextField tel = new JTextField();
        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();

        JPanel p = new JPanel(new GridLayout(7,2,6,6));
        p.add(new JLabel("Rol:")); p.add(rol);
        p.add(new JLabel("DNI:")); p.add(dni);
        p.add(new JLabel("Nombres:")); p.add(nom);
        p.add(new JLabel("Apellidos:")); p.add(ape);
        p.add(new JLabel("Teléfono:")); p.add(tel);
        p.add(new JLabel("Usuario:")); p.add(user);
        p.add(new JLabel("Contraseña:")); p.add(pass);

        int r = JOptionPane.showConfirmDialog(this, p, "Registrar Empleado", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        String tipo = (String) rol.getSelectedItem();

        Empleado e;

        if (tipo.equals("Administrador")) {
            e = new Administrador(
                dni.getText(), nom.getText(), ape.getText(),
                tel.getText(), user.getText(), new String(pass.getPassword())
            );
        } else {
            e = new Recepcionista(
                dni.getText(), nom.getText(), ape.getText(),
                tel.getText(), user.getText(), new String(pass.getPassword())
            );
        }

        db.agregarEmpleado(e);

        JOptionPane.showMessageDialog(this, "Empleado registrado correctamente.");
    }

    // ======================================================
    // REGISTRAR HABITACIÓN
    // ======================================================
    private void registrarHabitacion() {
        JTextField num = new JTextField();
        JTextField tipo = new JTextField();
        JTextField cap = new JTextField();
        JTextField precio = new JTextField();

        JPanel p = new JPanel(new GridLayout(4,2,6,6));
        p.add(new JLabel("Número:")); p.add(num);
        p.add(new JLabel("Tipo:")); p.add(tipo);
        p.add(new JLabel("Capacidad:")); p.add(cap);
        p.add(new JLabel("Precio por noche:")); p.add(precio);

        int r = JOptionPane.showConfirmDialog(this, p, "Registrar Habitación", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        try {
            Habitacion h = new Habitacion(
                Integer.parseInt(num.getText()),
                tipo.getText(),
                Integer.parseInt(cap.getText()),
                Double.parseDouble(precio.getText())
            );

            db.agregarHabitacion(h);
            JOptionPane.showMessageDialog(this, "Habitación agregada correctamente.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Datos inválidos.");
        }
    }

    // ======================================================
    // REGISTRAR SERVICIO
    // ======================================================
    private void registrarServicio() {
        JTextField nombre = new JTextField();
        JTextField precio = new JTextField();

        JPanel p = new JPanel(new GridLayout(2,2,6,6));
        p.add(new JLabel("Nombre servicio:")); p.add(nombre);
        p.add(new JLabel("Precio:")); p.add(precio);

        int r = JOptionPane.showConfirmDialog(this, p, "Registrar Servicio", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        try {
            Servicio s = new Servicio(nombre.getText(), Double.parseDouble(precio.getText()));
            db.agregarServicio(s);

            JOptionPane.showMessageDialog(this, "Servicio registrado correctamente.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Datos inválidos.");
        }
    }

    // ======================================================
    // MOSTRAR LISTAS
    // ======================================================
    private void mostrarListas(JTextArea area) {
        area.setText("");

        area.append("===== EMPLEADOS =====\n");
        for(int i=0; i<db.cantEmpleados; i++){
            if(db.empleados[i] != null) area.append(db.empleados[i] + "\n");
        }

        area.append("\n===== HABITACIONES =====\n");
        area.append(db.listarHabitaciones());

        area.append("\n===== SERVICIOS =====\n");
        area.append(db.listarServicios());

        area.append("\n===== HUESPEDES =====\n");
        for(int i=0; i<db.cantHuespedes; i++){
            if(db.huespedes[i] != null) area.append(db.huespedes[i] + "\n");
        }

        area.append("\n===== RESERVAS =====\n");
        area.append(db.listarReservas());
    }
}
